This archive includes icons in ICO, BMP, GIF, PNG formats.
24-bit bitmaps are supplied with white background for designers
and with fuchsia "transparent" color for developers.

How to use these icons with your development tools?
Please read here:
http://www.aha-soft.com/faq/integrating-icons-development-environments.htm
http://www.aha-soft.com/faq/using-stock-icons-in-your-project.htm


Aha-Soft offers graphic software products, stock icon sets, custom icon design.

Icon editors, cursor editors, image viwers and converters are ready to download here:
http://www.aha-soft.com/products.htm


IconLover is an icon editor. It allows you to design and edit all kinds of graphics
required in the software development cycle, including icons, static and animated
cursors and interface elements - all these kinds of graphics can now be designed
in a single application. 
http://www.small-icons.com/iconlover/index.htm


A lot of stock icons for Windows development, web design,
Android and iOS apps, Windows Mobile is here:
http://www.aha-soft.com/iconlibs.htm
http://www.777icons.com/
http://www.perfect-icons.com/
http://www.toolbar-icons.com/
http://www.large-icons.com/
http://www.small-icons.com/


Icon Design Service

We can design custom icons for you. Please find the basic information
about ordering icons, pricing and the portfolio here:
www.aha-soft.com/icon-design.htm


Support page: http://www.aha-soft.com/support.htm

Copyright � 2000-2012 Aha-Soft. All rights reserved. 